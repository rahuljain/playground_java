package problem1;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class MissingLetters {
	private HashMap<Character, Boolean> charMap;
	private void initializeCharMap() {
		charMap.clear();
		charMap.put('a', false);
		charMap.put('b', false);
		charMap.put('c', false);
		charMap.put('d', false);
		charMap.put('e', false);
		charMap.put('f', false);
		charMap.put('g', false);
		charMap.put('h', false);
		charMap.put('i', false);
		charMap.put('j', false);
		charMap.put('k', false);
		charMap.put('l', false);
		charMap.put('m', false);
		charMap.put('n', false);
		charMap.put('o', false);
		charMap.put('p', false);
		charMap.put('q', false);
		charMap.put('r', false);
		charMap.put('s', false);
		charMap.put('t', false);
		charMap.put('u', false);
		charMap.put('v', false);
		charMap.put('w', false);
		charMap.put('x', false);
		charMap.put('y', false);
		charMap.put('z', false);	
	}
	
	public MissingLetters() {
		this.charMap = new HashMap<Character, Boolean>();
	}
	
	public String getMissingLetters(String sentence) {
		this.initializeCharMap();
		String missing = new String();
		sentence = sentence.toLowerCase();
		int length = sentence.length();
		for(int i = 0; i < length; i++) {
			char c = sentence.charAt(i);
			if(this.charMap.containsKey(c)) {
				if(!this.charMap.get(c)) {	//first time we have encountered this character
					this.charMap.put(c, true);
				}
			}
		}
		for(Map.Entry<Character, Boolean> e : this.charMap.entrySet()) {
			if(!e.getValue()) {
				missing = missing.concat(e.getKey().toString());
			}
		}
		if(missing.length()==0) {
			return "";
		}
		char[] missingLetters = missing.toCharArray();
		Arrays.sort(missingLetters);
		return new String(missingLetters);
	}
}
