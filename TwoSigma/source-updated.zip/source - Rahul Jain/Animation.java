package problem2;

import java.util.ArrayList;

public class Animation {
	private ArrayList<String> moves;
	private Integer chamberLength;
	private Integer speed;
	
	protected class particle {
		protected Character c;
		protected Character dir;
		protected Integer pos;
		protected particle(Character direction, Integer position) {
			this.c = 'X';
			this.dir = direction;
			this.pos = position;
		}
	}
	
	public Animation() {
		this.moves = new ArrayList<String>();
		this.chamberLength = 0;
		this.speed = 0;
	}
	
	private void initialize(Integer spd, Integer len) {
		this.moves.clear();
		this.chamberLength = len;
		this.speed = spd;
	}
	private particle move(particle p) {
		if(p.dir.equals('L')) {
			p.pos -= this.speed;
		}
		else if(p.dir.equals('R')) {
			p.pos += this.speed;
		}
		return p;
	}
	
	public String[]animate(int speed, String init) {
		this.initialize(speed, init.length());
		ArrayList<particle> p = new ArrayList<particle>();
		for(int i = 0; i < this.chamberLength; i++) {
			if(init.charAt(i)!='.') {
				p.add(new particle(init.charAt(i), i));
			}
		}
		//Ran out of time.
		/*
		 * I would have ran a loop until the 'init' string becomes all dots.
		 * To do that, I would have checked if all the particles consisted in p have a position that is greater than 0 and less than
		 * the size of the init string.
		 * Until that happens call move function for the n particles and create a string based on the new positions.
		 * Add the string to the moves array.
		 * Finally return the string array as follows:
		 *
		 */
		String[] m = new String[moves.size()];
		return moves.toArray(m);		
	}

}
